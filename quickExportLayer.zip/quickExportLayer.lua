function init(plugin)
  plugin:newCommand{
    id="quick_export",
    title="Quick Export",
    group="layer_popup_properties",
    onclick=function()
      local sprite = app.sprite
      local currentLayer = app.layer
      local function getPath(filename)
        local separator = '/'
        if app.os.windows then
          separator = '\\'
        end
        return filename:match("(.*"..separator..")")
      end
      app.command.SaveFileCopyAs {
        ui=true,
        recent=false,
        filename= getPath(sprite.filename) .. currentLayer.name .. ".png",
        tag="",
        aniDir=AniDir,
        slice="",
        fromFrame=frame,
        toFrame=frame,
        ignoreEmpty=false,
        bounds=sprite.bounds,
      }
    end
  }
end

function exit(plugin)
end