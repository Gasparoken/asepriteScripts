local function execute()
  local sprite = app.sprite
  if not sprite then
    return app.alert("Error: no sprite.")
  end

  local palette = sprite.palettes[1]
  local newPalette = Palette(#palette)
  local repeatCounter = 0

  for i = 0, #palette-1 do
    local color = palette:getColor(i)
    newPalette:setColor(i - repeatCounter, color)
    for j = 0, i do
      if i ~= j and color == palette:getColor(j) then
        repeatCounter = repeatCounter + 1
        goto continue
      end
    end
    ::continue::
  end

  newPalette:resize(#palette - repeatCounter)

  app.transaction(
    "Removed duplicate colors from the palette.",
    function()
      for i = 0, #newPalette-1 do
        palette:setColor(i, newPalette:getColor(i))
      end
      palette:resize(#newPalette)
    end)
end

function init(plugin)
  plugin:newCommand{
    id="remove_duplicated_colors",
    title="Remove Duplicated Colors",
    group="palette_main",
    onclick=function()
      execute()
    end
  }
end

function exit(plugin)
end